enum Location
{
    DEFAULT, USA, INDIA
}
