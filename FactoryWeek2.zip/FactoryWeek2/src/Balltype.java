enum ballType
{
    Small, Medium, Large
}

